import numpy as np
from resampling import *

################### Class Components #################################################
# kernel size:  K;  type scalar;    kernel size
# stride:           type: scalar;   stride
# ------------------------------------------------------------------------------------
# A:    type: Matrix of N x C_in x H_in x W_in;     data input 
# Z:    type: Matrix of N x C_in x H_out x W_out;  features after pooling
# ------------------------------------------------------------------------------------
# dLdZ: type: Matrix of N x C_in x H_out x W_out;  how changes in outputs affect loss
# dLdA: type: Matrix of N x C_in x H_in x W_in;     how changes in inputs affect loss
######################################################################################

class MaxPool2d_stride1:

    def __init__(self, kernel):
        self.kernel = kernel

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_height, input_width)
        Return:
            Z (np.array): (batch_size, out_channels, input_height, input_width)
        """
        self.A = A
        batch_size, in_channels, input_height, input_width = A.shape
        K = self.kernel
        output_width = input_width - K + 1
        output_height = input_height - K + 1

        Z = np.zeros((batch_size, in_channels, output_height, output_width), dtype=A.dtype)
        for n in range(batch_size):
            for c in range(in_channels):
                for i in range(output_height):
                    for j in range(output_width):
                        window = A[n, c, i:i+K, j:j+K]
                        Z[n, c, i, j] = np.max(window)
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_height, output_width)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_height, input_width)
        """
        batch_size, in_channels, output_height, output_width = dLdZ.shape
        A = self.A
        _, _, input_height, input_width = A.shape

        K = self.kernel

        dLdA = np.zeros_like(A)
        for n in range(batch_size):
            for c in range(in_channels):
                for i in range(output_height):
                    for j in range(output_width):
                        window = A[n, c, i:i+K, j:j+K]
                        idx = np.argmax(window)
                        p, q = divmod(idx, K)   
                        dLdA[n, c, i+p, j+q] += dLdZ[n, c, i, j]

        return dLdA


class MeanPool2d_stride1:

    def __init__(self, kernel):
        self.kernel = kernel

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_height, input_width)
        Return:
            Z (np.array): (batch_size, out_channels, output_height, output_width)
        """
        self.A = A
        batch_size, in_channels, input_height, input_width = A.shape
        K = self.kernel
        output_height = input_height - K +1
        output_width = input_width - K +1

        Z = np.zeros((batch_size, in_channels, output_height, output_width), dtype=A.dtype)

        for n in range(batch_size):
            for c in range(in_channels):
                for i in range(output_height):
                    for j in range(output_width):
                        window = A[n, c, i:i+K, j:j+K]
                        Z[n, c, i, j] = np.mean(window)     # 1/K^2 * sum(window)


        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_height, output_width)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_height, input_width)
        """
        batch_size, in_channels, output_height, output_width = dLdZ.shape
        A = self.A
        batch_size, in_channels, input_height, input_width = A.shape
        K = self.kernel

        dLdA = np.zeros_like(A)
        coeff = 1.0 / (K * K)
        for n in range(batch_size):
            for c in range(in_channels):
                for i in range(output_height):
                    for j in range(output_width):
                        d = dLdZ[n, c, i, j] * coeff
                        dLdA[n, c, i:i+K, j:j+K] += d

        return dLdA


class MaxPool2d:

    def __init__(self, kernel, stride):
        self.kernel = kernel
        self.stride = stride

        # Create an instance of MaxPool2d_stride1
        self.maxpool2d_stride1 = MaxPool2d_stride1(kernel)
        self.downsample2d = Downsample2d(stride)

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_height, input_width)
        Return:
            Z (np.array): (batch_size, out_channels, output_height, output_width)
        """
        # use maxpool2d_stride1.forward
        Z = self.maxpool2d_stride1.forward(A)
        # downsample2d.forward
        Z = self.downsample2d.forward(Z)

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_height, output_width)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_height, input_width)
        """
        # TODO: use downsample2d.backward()
        dLdZ = self.downsample2d.backward(dLdZ)
        # TODO: use maxpool2d_stride1.backward()
        dLdA = self.maxpool2d_stride1.backward(dLdZ)

        return dLdA


class MeanPool2d:

    def __init__(self, kernel, stride):
        self.kernel = kernel
        self.stride = stride

        # Create an instance of MeanPool2d_stride1
        self.meanpool2d_stride1 = MeanPool2d_stride1(kernel)
        self.downsample2d = Downsample2d(stride)

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_height, input_width)
        Return:
            Z (np.array): (batch_size, out_channels, output_height, output_width)
        """
        #TODO use meanpool2d_stride1.forward()
        Z = self.meanpool2d_stride1.forward(A)
        #TODO use downsample2d.forward()
        Z = self.downsample2d.forward(Z)

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_height, output_width)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_height, input_width)
        """
        #TODO use downsample2d.backward()
        dLdZ = self.downsample2d.backward(dLdZ)
        #TODO use meanpool2d_stride1.backward()
        dLdA = self.meanpool2d_stride1.backward(dLdZ)

        return dLdA
